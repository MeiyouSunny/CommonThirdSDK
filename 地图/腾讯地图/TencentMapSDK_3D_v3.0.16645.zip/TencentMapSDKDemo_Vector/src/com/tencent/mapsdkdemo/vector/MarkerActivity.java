package com.tencent.mapsdkdemo.vector;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.tencentmap.mapsdk.maps.CameraUpdateFactory;
import com.tencent.tencentmap.mapsdk.maps.SupportMapFragment;
import com.tencent.tencentmap.mapsdk.maps.TencentMap;
import com.tencent.tencentmap.mapsdk.maps.TencentMap.InfoWindowAdapter;
import com.tencent.tencentmap.mapsdk.maps.TencentMap.OnInfoWindowClickListener;
import com.tencent.tencentmap.mapsdk.maps.TencentMap.OnMarkerClickListener;
import com.tencent.tencentmap.mapsdk.maps.TencentMap.OnMarkerDragListener;
import com.tencent.tencentmap.mapsdk.maps.TencentMap.ScreenShotReadyCallback;
import com.tencent.tencentmap.mapsdk.maps.model.BitmapDescriptorFactory;
import com.tencent.tencentmap.mapsdk.maps.model.CameraPosition;
import com.tencent.tencentmap.mapsdk.maps.model.LatLng;
import com.tencent.tencentmap.mapsdk.maps.model.Marker;
import com.tencent.tencentmap.mapsdk.maps.model.MarkerOptions;

public class MarkerActivity extends FragmentActivity {
	
	private TencentMap tencentMap;
	private boolean isMarkerAdded;
	
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		setContentView(R.layout.activity_marker_control);
		init();
		addMarker();
	}
	
	protected void init() {
		FragmentManager fm = getSupportFragmentManager();
		SupportMapFragment map = (SupportMapFragment)fm.findFragmentById(R.id.frag_map);
		tencentMap = map.getMap();
		tencentMap.moveCamera(CameraUpdateFactory.newCameraPosition(new 
				CameraPosition(new LatLng(34.611524,105.058565), 3, 0, 0)));
		tencentMap.getUiSettings().setZoomControlsEnabled(false);
		isMarkerAdded = false;
		Button btnScreenShot = (Button)findViewById(R.id.btn_screen_shot);
		Button btnReset = (Button)findViewById(R.id.btn_reset);
		Button btnClear = (Button)findViewById(R.id.btn_clear);
		OnClickListener onClickListener = new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				switch (v.getId()) {
				case R.id.btn_reset:
					if (!isMarkerAdded) {
						addMarker();
					}
					break;
				case R.id.btn_clear:
					tencentMap.clear();
					isMarkerAdded = false;
					break;
				case R.id.btn_screen_shot:
					shotScreen();
					break;

				default:
					break;
				}
			}
		};
		btnReset.setOnClickListener(onClickListener);
		btnClear.setOnClickListener(onClickListener);
		btnScreenShot.setOnClickListener(onClickListener);
	}
	
	protected void shotScreen() {
		Bitmap.Config config = Config.ARGB_8888;
		Handler handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				// TODO Auto-generated method stub
				super.handleMessage(msg);
				if (msg == null || msg.obj == null) {
					return;
				}
				Bitmap screen = (Bitmap)msg.obj;
				Toast toast = new Toast(MarkerActivity.this);
				LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
				ImageView imageView = new ImageView(MarkerActivity.this);
				imageView.setLayoutParams(lp);
				imageView.setImageBitmap(screen);
				LinearLayout ll = new LinearLayout(MarkerActivity.this);
				ll.setLayoutParams(lp);
				ll.setGravity(Gravity.CENTER);
				ll.setPadding(10, 10, 10, 10);
				ll.addView(imageView);
				toast.setMargin(20f, 20f);
				toast.setView(ll);
				toast.setDuration(Toast.LENGTH_SHORT);
				toast.show();
			}
		};
//		tencentMap.getScreenShot(handler, config);
		tencentMap.getScreenShot(new ScreenShotReadyCallback() {
			
			@Override
			public void onScreenShotReady(Bitmap arg0) {
				// TODO Auto-generated method stub
				Toast toast = new Toast(MarkerActivity.this);
				LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
				ImageView imageView = new ImageView(MarkerActivity.this);
				imageView.setLayoutParams(lp);
				imageView.setImageBitmap(arg0);
				LinearLayout ll = new LinearLayout(MarkerActivity.this);
				ll.setLayoutParams(lp);
				ll.setGravity(Gravity.CENTER);
				ll.setPadding(10, 10, 10, 10);
				ll.addView(imageView);
				toast.setMargin(20f, 20f);
				toast.setView(ll);
				toast.setDuration(Toast.LENGTH_SHORT);
				toast.show();
			}
		});
	}
	
	protected void addMarker() {
		isMarkerAdded = true;
		Marker beiJingMarker = tencentMap.addMarker(new MarkerOptions().
				position(new LatLng(39.906901,116.397972)).
				icon(BitmapDescriptorFactory.defaultMarker()).
				title("北京").
				snippet("DefaultMarker"));
		final Marker shangHaiMarker = tencentMap.addMarker(new MarkerOptions().
				position(new LatLng(31.247241,121.492696)).
				icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)).
				title("上海").
				snippet("Click infowindow to change icon"));
		Marker jiNanMarker = tencentMap.addMarker(new MarkerOptions().
				position(new LatLng(36.666574,117.028908)).
				icon(BitmapDescriptorFactory.fromAsset("iron_man.ico")).
				title("济南").
				snippet("icon from assets").
				anchor(0.5f, 1f));
		Marker zhengZhouMarker = tencentMap.addMarker(new MarkerOptions().
				position(new LatLng(34.783726,113.670430)).
				icon(BitmapDescriptorFactory.fromBitmap(
						BitmapFactory.decodeResource(getResources(), R.drawable.death_star))).
				title("郑州").
				snippet("icon from bitmap").
				anchor(0.5f, 0.5f));
		
		FileOutputStream fos;
		File file = new File(getFilesDir(), "myicon.ico");
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Bitmap bmp = BitmapFactory.decodeResource(getResources(), R.drawable.super_man);
		bmp.compress(CompressFormat.PNG, 100, baos);
		try {
			fos = openFileOutput(file.getName(), MODE_PRIVATE);
			fos.write(baos.toByteArray());
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Marker chengDuMarker = tencentMap.addMarker(new MarkerOptions().
				position(new LatLng(30.661821,104.066603)).
				icon(BitmapDescriptorFactory.fromFile(file.getName())).
				title("成都").
				snippet("icon from file"));
		Marker wuLuMuQiMarker = tencentMap.addMarker(new MarkerOptions().
				position(new LatLng(43.831910,87.592552)).
				icon(BitmapDescriptorFactory.
						fromPath(getFilesDir() + "/" + file.getName())).
				title("乌鲁木齐").
				snippet("icon from path"));
		Marker hongkongMarker = tencentMap.addMarker(new MarkerOptions().
				position(new LatLng(22.318541,114.174108)).
				icon(BitmapDescriptorFactory.fromResource(R.drawable.hulk)).
				title("香港").
				snippet("icon from resource"));
		
		final Marker marker = tencentMap.addMarker(new MarkerOptions().
				position(new LatLng(25.046083,121.513000)).
				title("cust infowindow").
				snippet("25.046083,121.513000"));

		InfoWindowAdapter infoWindowAdapter = new InfoWindowAdapter() {
			
			TextView tvTitle;
			CheckBox cbDraggable;
			SeekBar sbTransparency;
			
			@Override
			public View getInfoWindowPressState(Marker arg0) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public View getInfoWindow(final Marker arg0) {
				// TODO Auto-generated method stub
				if (arg0.equals(marker)) {
					LinearLayout custInfowindow = (LinearLayout) View.inflate(
							MarkerActivity.this, R.layout.cust_infowindow, null);
					tvTitle = (TextView)custInfowindow.findViewById(R.id.tv_title);
					cbDraggable = (CheckBox)custInfowindow.findViewById(R.id.cb_draggable);
					sbTransparency = (SeekBar)custInfowindow.findViewById(R.id.sb_transparency);
					tvTitle.setText(arg0.getTitle());
					cbDraggable.setChecked(arg0.isDraggable());
					sbTransparency.setProgress((int)(100 * arg0.getAlpha()));
					cbDraggable.setOnCheckedChangeListener(new OnCheckedChangeListener() {
						
						@Override
						public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
							// TODO Auto-generated method stub
							arg0.setDraggable(isChecked);
						}
					});
					sbTransparency.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
						
						@Override
						public void onStopTrackingTouch(SeekBar seekBar) {
							// TODO Auto-generated method stub
							
						}
						
						@Override
						public void onStartTrackingTouch(SeekBar seekBar) {
							// TODO Auto-generated method stub
							
						}
						
						@Override
						public void onProgressChanged(SeekBar seekBar, int progress,
								boolean fromUser) {
							// TODO Auto-generated method stub
							arg0.setAlpha((float)progress / sbTransparency.getMax());
						}
					});
					return custInfowindow;
				}
				return null;
			}
			
			@Override
			public View getInfoContents(Marker arg0) {
				// TODO Auto-generated method stub
				return null;
			}
		};
		
		tencentMap.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {
			
			@Override
			public void onInfoWindowClick(Marker arg0) {
				// TODO Auto-generated method stub
				if (arg0.equals(shangHaiMarker)) {
					arg0.setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
				}
			}
		});
		
		tencentMap.setInfoWindowAdapter(infoWindowAdapter);
		tencentMap.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {
			
			@Override
			public void onInfoWindowClick(Marker arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		tencentMap.setOnMarkerClickListener(new OnMarkerClickListener() {
			
			@Override
			public boolean onMarkerClick(Marker arg0) {
				// TODO Auto-generated method stub
				arg0.hideInfoWindow();
				return false;
			}
		});
		
		tencentMap.setOnMarkerDragListener(new OnMarkerDragListener() {
			
			@Override
			public void onMarkerDragStart(Marker arg0) {
				// TODO Auto-generated method stub
				arg0.setSnippet("drag start");
			}
			
			@Override
			public void onMarkerDragEnd(Marker arg0) {
				// TODO Auto-generated method stub
				arg0.setSnippet("drag end");
			}
			
			@Override
			public void onMarkerDrag(Marker arg0) {
				// TODO Auto-generated method stub
				arg0.setSnippet("dragging");
			}
		});
	}
}
