package com.baidu.mobstat.demo;

import android.app.Application;

public class MyApplication extends Application {

    public static final boolean SHIELD_EXCEPTION = false;

    @Override
    public void onCreate() {
        super.onCreate();
    }

}
