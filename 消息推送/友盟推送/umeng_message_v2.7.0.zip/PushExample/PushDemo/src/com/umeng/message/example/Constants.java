package com.umeng.message.example;

public class Constants {
	
	public static final int UPDATE_LOCAL_NOTIFICATION = 1;
	public static final int CREATE_LOCAL_NOTIFICATION = 2;
	public static final int ADD_LOCAL_NOTIFICATION = 3;
	public static final int CLEAR_LOCAL_NOTIFICATION = 4;
	public static final int DELETE_LOCAL_NOTIFICATION = 5;

}
